package com.example.calculator

import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: LinearLayout
    private lateinit var history: TextView
    private lateinit var expression: TextView
    private lateinit var screen: TextView

    private lateinit var numButtons: List<Button>
    private lateinit var lightButtons: List<Button>
    private lateinit var opButtons: List<Button>
    private lateinit var eqButton: Button
    private lateinit var themeButton: Button

    private var currentNumber = ""
    private var lastNumber = ""
    private var operation = ""
    private var memory = 0.0
    private var isDark = true
    private var startY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupButtons()
        setupSwipeToClear()
        applyTheme()
    }

    private fun bindViews() {
        rootLayout = findViewById(R.id.rootLayout)
        history = findViewById(R.id.history)
        expression = findViewById(R.id.expression)
        screen = findViewById(R.id.screen)

        val btn0 = findViewById<Button>(R.id.btn0)
        val btn1 = findViewById<Button>(R.id.btn1)
        val btn2 = findViewById<Button>(R.id.btn2)
        val btn3 = findViewById<Button>(R.id.btn3)
        val btn4 = findViewById<Button>(R.id.btn4)
        val btn5 = findViewById<Button>(R.id.btn5)
        val btn6 = findViewById<Button>(R.id.btn6)
        val btn7 = findViewById<Button>(R.id.btn7)
        val btn8 = findViewById<Button>(R.id.btn8)
        val btn9 = findViewById<Button>(R.id.btn9)
        val btnDot = findViewById<Button>(R.id.btnDot)

        val btnClear = findViewById<Button>(R.id.btnClear)
        val btnPlusMinus = findViewById<Button>(R.id.btnPlusMinus)
        val btnPercent = findViewById<Button>(R.id.btnPercent)
        val btnMPlus = findViewById<Button>(R.id.btnMPlus)
        val btnMMinus = findViewById<Button>(R.id.btnMMinus)
        val btnMR = findViewById<Button>(R.id.btnMR)

        val btnPlus = findViewById<Button>(R.id.btnPlus)
        val btnMinus = findViewById<Button>(R.id.btnMinus)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)

        val btnEquals = findViewById<Button>(R.id.btnEquals)
        val btnTheme = findViewById<Button>(R.id.btnTheme)

        numButtons = listOf(btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnDot)
        lightButtons = listOf(btnClear, btnPlusMinus, btnPercent, btnMPlus, btnMMinus, btnMR, btnTheme)
        opButtons = listOf(btnPlus, btnMinus, btnMultiply, btnDivide)
        eqButton = btnEquals
        themeButton = btnTheme
    }

    private fun setupButtons() {
        // Copy result on long press
        screen.setOnLongClickListener {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("result", screen.text)
            clipboard.setPrimaryClip(clip)
            true
        }

        // Digits
        val digitMap = mapOf(
            R.id.btn0 to "0",
            R.id.btn1 to "1",
            R.id.btn2 to "2",
            R.id.btn3 to "3",
            R.id.btn4 to "4",
            R.id.btn5 to "5",
            R.id.btn6 to "6",
            R.id.btn7 to "7",
            R.id.btn8 to "8",
            R.id.btn9 to "9"
        )

        for ((id, digit) in digitMap) {
            val button = findViewById<Button>(id)
            button.setOnClickListener {
                animateButton(button)
                appendDigit(digit)
            }
        }

        // Dot
        val btnDot = findViewById<Button>(R.id.btnDot)
        btnDot.setOnClickListener {
            animateButton(btnDot)
            if (!currentNumber.contains(".")) {
                currentNumber += if (currentNumber.isEmpty()) "0." else "."
                updateScreen()
            }
        }

        // Operations
        val btnPlus = findViewById<Button>(R.id.btnPlus)
        val btnMinus = findViewById<Button>(R.id.btnMinus)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)

        btnPlus.setOnClickListener {
            animateButton(btnPlus)
            setOp("+")
        }
        btnMinus.setOnClickListener {
            animateButton(btnMinus)
            setOp("-")
        }
        btnMultiply.setOnClickListener {
            animateButton(btnMultiply)
            setOp("*")
        }
        btnDivide.setOnClickListener {
            animateButton(btnDivide)
            setOp("/")
        }

        // Clear
        val btnClear = findViewById<Button>(R.id.btnClear)
        btnClear.setOnClickListener {
            animateButton(btnClear)
            clearAll()
        }

        // Percent
        val btnPercent = findViewById<Button>(R.id.btnPercent)
        btnPercent.setOnClickListener {
            animateButton(btnPercent)
            if (currentNumber.isNotEmpty()) {
                val value = currentNumber.toDouble() / 100.0
                currentNumber = formatNumber(value)
                updateScreen()
            }
        }

        // +/- toggle
        val btnPlusMinus = findViewById<Button>(R.id.btnPlusMinus)
        btnPlusMinus.setOnClickListener {
            animateButton(btnPlusMinus)
            if (currentNumber.isNotEmpty()) {
                currentNumber = if (currentNumber.startsWith("-")) {
                    currentNumber.substring(1)
                } else {
                    "-$currentNumber"
                }
                updateScreen()
            }
        }

        // Memory buttons
        val btnMPlus = findViewById<Button>(R.id.btnMPlus)
        val btnMMinus = findViewById<Button>(R.id.btnMMinus)
        val btnMR = findViewById<Button>(R.id.btnMR)

        btnMPlus.setOnClickListener {
            animateButton(btnMPlus)
            val value = screen.text.toString().toDoubleOrNull() ?: 0.0
            memory += value
        }

        btnMMinus.setOnClickListener {
            animateButton(btnMMinus)
            val value = screen.text.toString().toDoubleOrNull() ?: 0.0
            memory -= value
        }

        btnMR.setOnClickListener {
            animateButton(btnMR)
            currentNumber = formatNumber(memory)
            updateScreen()
        }

        // Equals
        val btnEquals = findViewById<Button>(R.id.btnEquals)
        btnEquals.setOnClickListener {
            animateButton(btnEquals)
            if (lastNumber.isNotEmpty() && currentNumber.isNotEmpty() && operation.isNotEmpty()) {
                val expText = "$lastNumber $operation $currentNumber"
                val resultValue = calculate()
                if (resultValue.isNaN()) {
                    screen.text = "Error"
                } else {
                    val resultText = formatNumber(resultValue)
                    addToHistory("$expText = $resultText")
                    screen.text = resultText
                    lastNumber = resultText
                }
                currentNumber = ""
                operation = ""
                expression.text = ""
            }
        }

        // Theme toggle
        themeButton.setOnClickListener {
            animateButton(themeButton)
            isDark = !isDark
            applyTheme()
        }
    }

    private fun appendDigit(digit: String) {
        if (currentNumber == "0") {
            currentNumber = digit
        } else {
            currentNumber += digit
        }
        updateScreen()
    }

    private fun setOp(op: String) {
        if (currentNumber.isNotEmpty()) {
            if (lastNumber.isNotEmpty() && operation.isNotEmpty()) {
                val resultValue = calculate()
                if (!resultValue.isNaN()) {
                    lastNumber = formatNumber(resultValue)
                    screen.text = lastNumber
                }
            } else {
                lastNumber = currentNumber
            }
            currentNumber = ""
            operation = op
            expression.text = "$lastNumber $operation"
        }
    }

    private fun calculate(): Double {
        val a = lastNumber.toDoubleOrNull() ?: return Double.NaN
        val b = currentNumber.toDoubleOrNull() ?: return Double.NaN

        return when (operation) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b == 0.0) Double.NaN else a / b
            else -> Double.NaN
        }
    }

    private fun clearAll() {
        currentNumber = ""
        lastNumber = ""
        operation = ""
        screen.text = "0"
        expression.text = ""
    }

    private fun updateScreen() {
        screen.text = if (currentNumber.isEmpty()) "0" else currentNumber
        if (operation.isNotEmpty() && lastNumber.isNotEmpty()) {
            expression.text = "$lastNumber $operation"
        }
    }

    private fun formatNumber(num: Double): String {
        return if (num == num.toInt().toDouble()) {
            num.toInt().toString()
        } else {
            num.toString()
        }
    }

    private fun addToHistory(line: String) {
        val current = history.text.toString()
        val lines = if (current.isEmpty()) {
            listOf(line)
        } else {
            current.split("\n") + line
        }
        val lastLines = lines.takeLast(3)
        history.text = lastLines.joinToString("\n")
    }

    private fun animateButton(btn: Button) {
        val anim = AnimationUtils.loadAnimation(this, R.anim.button_scale)
        btn.startAnimation(anim)
        haptic()
    }

    private fun haptic() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(40)
        }
    }

    private fun setupSwipeToClear() {
        rootLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val deltaY = event.y - startY
                    if (deltaY > 150) {
                        clearAll()
                    }
                }
            }
            false
        }
    }

    private fun applyTheme() {
        if (isDark) {
            rootLayout.setBackgroundColor(Color.parseColor("#111111"))
            history.setTextColor(Color.parseColor("#777777"))
            expression.setTextColor(Color.parseColor("#AAAAAA"))
            screen.setTextColor(Color.WHITE)

            setTextColors(numButtons, Color.WHITE)
            setTextColors(lightButtons, Color.parseColor("#CCCCCC"))
            setTextColors(opButtons, Color.parseColor("#FF9F0A"))
            eqButton.setTextColor(Color.parseColor("#34C759"))
            themeButton.text = "☀"
        } else {
            rootLayout.setBackgroundColor(Color.WHITE)
            history.setTextColor(Color.parseColor("#666666"))
            expression.setTextColor(Color.parseColor("#999999"))
            screen.setTextColor(Color.BLACK)

            setTextColors(numButtons, Color.BLACK)
            setTextColors(lightButtons, Color.parseColor("#666666"))
            setTextColors(opButtons, Color.parseColor("#FF3B30"))
            eqButton.setTextColor(Color.parseColor("#007AFF"))
            themeButton.text = "☾"
        }
    }

    private fun setTextColors(buttons: List<Button>, color: Int) {
        for (b in buttons) {
            b.setTextColor(color)
        }
    }
}